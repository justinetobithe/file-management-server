<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Records Digitization Monitoring Form</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f4f6;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .header img {
            width: 120px;
            height: 120px;
        }

        .header-title {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .header-info {
            font-size: 12px;
            text-align: right;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 5px;
            text-align: left;
        }

        th {
            background-color: #e5e7eb;
            color: #333;
        }

        td {
            word-wrap: break-word;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 150px;
        }

        .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            font-size: 12px;
        }

        .signature-box {
            width: 45%;
        }

        .signature-box p {
            margin: 5px 0;
        }

        .bold {
            font-weight: bold;
        }

        .subfolder-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
        }

        .subfolder-item {
            display: flex;
            justify-content: space-between;
            border: 1px solid #ccc;
            padding: 5px;
            min-width: 120px;
            align-items: center;
        }

        .subfolder-name {
            flex: 1;
        }

        .subfolder-size {
            text-align: right;
            min-width: 80px;
        }
    </style>
</head>

<body>

    <div class="container">

        <div class="header">
            <div class="logo">
                <img src="<?php echo e(asset('http://127.0.0.1:8000/img/logo.png')); ?>" alt="PAGCOR Logo">
            </div>
            <div class="title">
                <div class="header-title">Records Digitization Monitoring Form</div>
            </div>
            <div class="header-info">
                <p><strong>Page No.:</strong> Page 1 of 1</p>
                <p><strong>Form No.:</strong> RMD - 409</p>
                <p><strong>Revision No.:</strong> 2</p>
                <p><strong>Effectivity:</strong> <?php echo e(\Carbon\Carbon::parse($reportData['effectiveDate'])->format('M. d, Y')); ?></p>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Department</th>
                    <th>Folder Name (Main)</th>
                    <th>Folder Name (Sub)</th>
                    <th>Size</th>
                    <th>Folder Location</th>
                    <th>Coverage Period</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reportData['folders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php $__currentLoopData = $folder['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($department['name']); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>

                    <td><?php echo e($folder['folder_name']); ?></td>

                    <td>
                        <ul class="subfolder-list">
                            <?php $__currentLoopData = $folder['subfolders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfolder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="subfolder-item">
                                <div class="subfolder-name">
                                    <?php echo e($subfolder['folder_name']); ?>

                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <ul class="subfolder-list">
                            <?php $__currentLoopData = $folder['subfolders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfolder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="subfolder-item">
                                <div class="subfolder-name">
                                    <?php echo e($subfolder['total_size']); ?>

                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>

                    <td><?php echo e($folder['local_path']); ?></td>

                    <td>
                        <?php echo e(\Carbon\Carbon::parse($folder['start_date'])->format('M. d, Y')); ?> –
                        <?php echo e(\Carbon\Carbon::parse($folder['end_date'])->format('M. d, Y')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="signature-section">
            <div class="signature-box">
                <p class="bold">Prepared By:</p>
                <p><?php echo e($reportData['user']['first_name']); ?> <?php echo e($reportData['user']['last_name']); ?></p>
                <p><?php echo e($reportData['user']['designation']['designation'] ?? ''); ?></p>
                <p>Date: _______________</p>
            </div>
            <div class="signature-box">
                <p class="bold">Checked By:</p>
                <p><?php echo e($reportData['checkedBy']['first_name']); ?> <?php echo e($reportData['checkedBy']['last_name']); ?></p>
                <p><?php echo e($reportData['checkedBy']['designation']['designation'] ?? ''); ?></p>
                <p>Date: _______________</p>
            </div>
        </div>
    </div>

</body>

</html><?php /**PATH D:\Projects\file-management-server\resources\views/report.blade.php ENDPATH**/ ?>